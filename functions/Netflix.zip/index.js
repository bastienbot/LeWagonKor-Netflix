const movies = require('./movies.json');

function compare(a, b) {
  if (a.year < b.year) return 1;
  if (a.year > b.year) return -1;
  return 0;
}

const findMovies = async function findMovies(event) {
  let res = movies;
  if (event.genre && event.genre.length > 0 && event.genre !== 'any') {
    res = res.filter((m) => m.genres.indexOf(event.genre) !== -1);
  }
  if (event.type && event.type.length > 0 && event.type !== 'any') {
    res = res.filter((m) => m.vtype.indexOf(event.type) !== -1);
  }
  if (event.year && event.year.length > 0 && event.year !== 'any') {
    res = res.filter((m) => m.year.toString() === event.year);
  }
  if (event.sort) {
    res = res.sort(compare);
  } else {
    res = res.sort(() => Math.random() - 0.5);
  }
  return res
    .slice(0, 5)
    .map((m) => ({
      id: m.id,
      title: m.title,
      img: m.img,
      type: m.vtype,
      nfid: m.nfid,
      genres: m.genres,
      synopsis: m.synopsis,
      avgrating: m.avgrating,
      year: m.year,
      imdbid: m.imdbid,
    }));
};
exports.handler = async (event) => findMovies(event);
