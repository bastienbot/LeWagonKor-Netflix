/**
 * This function is setup to run on nodejs 12.x:
 * https://nodejs.org/dist/latest-v12.x/docs/api/
 *
 * You can modify it to return an object, a string, a number, an array...
 * All native node modules are available with require() syntax.
 *
 * To import additional modules (i.e with npm install), or if your function
 * is larger than 4096 characters, please use the Complete Mode and package
 * your function with its dependencies in a zip file.
 *
 * See the documentation:
 * https://docs.csml.dev/studio/getting-started/using-csml-apps#using-custom-code
 */
exports.handler = async (event) => {
  // --- add your code below this line ---

  return encodeURI(event.url);

  // --- add your code above this line ---
}
